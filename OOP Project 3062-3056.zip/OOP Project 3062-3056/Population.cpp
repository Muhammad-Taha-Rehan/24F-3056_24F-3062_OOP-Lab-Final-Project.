#include "Stronghold.h"
#include<iostream>

using namespace std;

Population::Population(int t)
{
	totalPopulation = t;
	deaths = 0;
	births = 0;
	sick = 0;
	shelter = 0;
}



void Population::updatePop(const Resources& res)
{
	int foodSupply = res.getFood();
	if (foodSupply < totalPopulation) {
		sick = (totalPopulation - foodSupply) / 10;
		deaths = (totalPopulation - foodSupply) / 20;
		totalPopulation -= deaths;
	}
	else
	{
		deaths = 0;
		sick = 0;
	}
	if (shelter < totalPopulation / 2)
		births = shelter / 20;
	else
		births = shelter / 10;

	totalPopulation += births;
	totalPopulation = max(0, totalPopulation);
}

bool Population::isStable()
{
	return sick < totalPopulation / 10 && deaths < totalPopulation / 25;
}

void Population::displayPop() const
{
	cout << "Total Population: " << totalPopulation << endl;
	cout << "Births: " << births << ", Ill: " << sick << ", Deaths: " << deaths << endl;
}