#include "Stronghold.h"
#include <iostream>

using namespace std;

Bank::Bank() : interestRate(0.1f), corruptionRate(0.0f), loanDebt(0.0f) {}

void Bank::takeLoan(Economy& economy, float amount) {
    if (amount > 0 && loanDebt == 0) {
        economy.adjustTaxRate(economy.getTaxRate() + 0.02f);
        economy.applyInflation();
        loanDebt = amount * 1.2f;
        economy.adjustTreasury(static_cast<int>(amount));
        corruptionRate += 5.0f;
    }
}

void Bank::repayLoan(Economy& economy, float amount) {
    if (amount >= loanDebt) {
        economy.adjustTaxRate(economy.getTaxRate() - 0.02f);
        loanDebt = 0;
    }
    else {
        loanDebt -= amount;
        corruptionRate -= 2.0f;
    }
    if (corruptionRate < 0) corruptionRate = 0;
}

void Bank::conductAudit(Economy& economy) {
    if (corruptionRate > 30.0f) {
        economy.adjustTreasury(-500);
        corruptionRate *= 0.5f;
    }
}

void Bank::displayBank() const {
    cout << "\n|-|-|-Bank System-|-|-|" << endl;
    cout << "Active Loan: " << loanDebt << " gold\n";
    cout << "Interest Rate: " << (interestRate * 100) << "%\n";
    cout << "Corruption Level: " << corruptionRate << "%\n";
}