#include "Stronghold.h"
#include <iostream>

using namespace std;

Resources::Resources(int f, int w, int s, int i)
    : totalFood(f), woods(w), stones(s), iron(i) {
}

bool Resources::consumeFood(int amount) {
    if (totalFood >= amount) {
        totalFood -= amount;
        return true;
    }
    totalFood = 0;
    return false;
}

void Resources::gatherFood(int amount) {
    totalFood += amount;
    if (totalFood > 1000) totalFood = 1000;
}

bool Resources::consumeWood(int amount) {
    if (woods >= amount) {
        woods -= amount;
        return true;
    }
    woods = 0;
    return false;
}

void Resources::gatherStone(int amount) {
    stones += amount;
    if (stones > 300) stones = 300;
}

void Resources::gatherIron(int amount) {
    iron += amount;
    if (iron > 200) iron = 200;
}

bool Resources::consumeStone(int amount) {
    if (stones >= amount) {
        stones -= amount;
        return true;
    }
    return false;
}

bool Resources::consumeIron(int amount) {
    if (iron >= amount) {
        iron -= amount;
        return true;
    }
    return false;
}

void Resources::gatherWood(int amount) {
    woods += amount;
    if (woods > 500) woods = 500;
}

void Resources::processSpoilage() {
    totalFood -= static_cast<int>(totalFood * 0.05);
    if (totalFood < 0) totalFood = 0;
}


void Resources::displayResources() const {
    cout << "\n|-|-|-Resources-|-|-|" << endl;
    cout << "Food: " << totalFood << " units\n";
    cout << "Wood: " << woods << " logs\n";
    cout << "Stone: " << stones << " blocks\n";
    cout << "Iron: " << iron << " ingots\n";
}

