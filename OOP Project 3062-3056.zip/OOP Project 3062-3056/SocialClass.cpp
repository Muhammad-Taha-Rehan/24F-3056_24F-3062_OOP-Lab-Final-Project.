#include "Stronghold.h"

using namespace std;

SocialClass::SocialClass(string n, int pop)
{
	typeName = n;
	population = pop;
	happinessPercentage = 70.0;
}

int SocialClass::getPopulation() const {
	return population;
}



void SocialClass::display() const
{
	cout << "Type: " << typeName;
	cout << "\nPopulation: " << population;
	cout << "\nHappiness: " << happinessPercentage << "%" << endl;
}

Peasant::Peasant(int pop) : SocialClass("Peasant", pop) {}

void Peasant::updatePeasant()
{
	if (population >= 150)
		happinessPercentage -= 4;
	else
		happinessPercentage += 2;
	if (happinessPercentage > 100)
		happinessPercentage = 100;
	if (happinessPercentage < 0)
		happinessPercentage = 0;
}

Merchant::Merchant(int pop) : SocialClass("Merchant", pop) {}

void Merchant::updateMerchant()
{
	happinessPercentage += 2;

	if (happinessPercentage > 100)
		happinessPercentage = 100;

}

Noble::Noble(int pop) : SocialClass("Noble", pop) {}

void Noble::updateNoble()
{
	happinessPercentage += 1;

	if (happinessPercentage > 100)
		happinessPercentage = 100;
}

